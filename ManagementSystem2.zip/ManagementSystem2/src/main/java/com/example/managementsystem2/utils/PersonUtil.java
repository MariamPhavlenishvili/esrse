package com.example.managementsystem2.utils;

import com.example.managementsystem2.models.Person;
import java.util.ArrayList;
import java.util.List;

public class PersonUtil {
    private static PersonUtil personUtil;
    private List<Person> persons;

    private PersonUtil() {
        persons = new ArrayList<Person>();
    }

    public List<Person> getPersons() {
        return persons;
    }

    public void addPerson(Person person){
        persons.add(person);
    }

    public boolean removePerson(int index){
        return persons.remove(index) != null;
    }

    public static PersonUtil getInstance(){
        if(PersonUtil.personUtil == null)
            PersonUtil.personUtil = new PersonUtil();

        return PersonUtil.personUtil;
    }
}
